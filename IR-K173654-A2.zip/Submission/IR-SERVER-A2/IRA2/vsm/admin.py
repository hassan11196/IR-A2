from django.contrib import admin
from .models import VectorSpaceModel
# Register your models here.
admin.site.register(VectorSpaceModel)