from django.apps import AppConfig


class VsmConfig(AppConfig):
    name = 'vsm'
